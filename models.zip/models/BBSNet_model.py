import torch
import torch.nn as nn
import torchvision.models as models
from ResNet import ResNet50
from torch.nn import functional as F
# from models.pvt import pvt_v2_b2


def conv3x3(in_planes, out_planes, stride=1):
    "3x3 convolution with padding"
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=1, bias=False)


class TransBasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, upsample=None, **kwargs):
        super(TransBasicBlock, self).__init__()
        self.conv1 = conv3x3(inplanes, inplanes)
        self.bn1 = nn.BatchNorm2d(inplanes)
        self.relu = nn.ReLU(inplace=True)
        if upsample is not None and stride != 1:
            self.conv2 = nn.ConvTranspose2d(inplanes, planes,
                                            kernel_size=3, stride=stride, padding=1,
                                            output_padding=1, bias=False)
        else:
            self.conv2 = conv3x3(inplanes, planes, stride)
        self.bn2 = nn.BatchNorm2d(planes)
        self.upsample = upsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.upsample is not None:
            residual = self.upsample(x)

        out += residual
        out = self.relu(out)

        return out


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()

        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = max_out
        x = self.conv1(x)
        return self.sigmoid(x)


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x


# Global Contextual module
class GCM(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(GCM, self).__init__()
        self.relu = nn.ReLU(True)
        self.branch0 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, 1),
        )
        self.branch1 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, 1),
            BasicConv2d(out_channel, out_channel, kernel_size=(1, 3), padding=(0, 1)),
            BasicConv2d(out_channel, out_channel, kernel_size=(3, 1), padding=(1, 0)),
            BasicConv2d(out_channel, out_channel, 3, padding=3, dilation=3)
        )
        self.branch2 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, 1),
            BasicConv2d(out_channel, out_channel, kernel_size=(1, 5), padding=(0, 2)),
            BasicConv2d(out_channel, out_channel, kernel_size=(5, 1), padding=(2, 0)),
            BasicConv2d(out_channel, out_channel, 3, padding=5, dilation=5)
        )
        self.branch3 = nn.Sequential(
            BasicConv2d(in_channel, out_channel, 1),
            BasicConv2d(out_channel, out_channel, kernel_size=(1, 7), padding=(0, 3)),
            BasicConv2d(out_channel, out_channel, kernel_size=(7, 1), padding=(3, 0)),
            BasicConv2d(out_channel, out_channel, 3, padding=7, dilation=7)
        )
        self.conv_cat = BasicConv2d(4 * out_channel, out_channel, 3, padding=1)
        self.conv_res = BasicConv2d(in_channel, out_channel, 1)

    def forward(self, x):
        x0 = self.branch0(x)
        x1 = self.branch1(x)
        x2 = self.branch2(x)
        x3 = self.branch3(x)

        x_cat = self.conv_cat(torch.cat((x0, x1, x2, x3), 1))

        x = self.relu(x_cat + self.conv_res(x))
        return x


# aggregation of the high-level(teacher) features
class aggregation_init(nn.Module):

    def __init__(self, channel):
        super(aggregation_init, self).__init__()
        self.relu = nn.ReLU(True)

        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.conv_upsample1 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample2 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample3 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample4 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample5 = BasicConv2d(2 * channel, 2 * channel, 3, padding=1)

        self.conv_concat2 = BasicConv2d(2 * channel, 2 * channel, 3, padding=1)
        self.conv_concat3 = BasicConv2d(3 * channel, 3 * channel, 3, padding=1)
        self.conv4 = BasicConv2d(3 * channel, 3 * channel, 3, padding=1)
        self.conv5 = nn.Conv2d(3 * channel, 1, 1)

    def forward(self, x1, x2, x3):
        x1_1 = x1
        x2_1 = self.conv_upsample1(self.upsample(x1)) * x2
        x3_1 = self.conv_upsample2(self.upsample(self.upsample(x1))) \
               * self.conv_upsample3(self.upsample(x2)) * x3

        x2_2 = torch.cat((x2_1, self.conv_upsample4(self.upsample(x1_1))), 1)
        x2_2 = self.conv_concat2(x2_2)

        x3_2 = torch.cat((x3_1, self.conv_upsample5(self.upsample(x2_2))), 1)
        x3_2 = self.conv_concat3(x3_2)

        x1 = self.conv4(x3_2)
        x = self.conv5(x1)

        return x, x1


# aggregation of the low-level(student) features
class aggregation_final(nn.Module):

    def __init__(self, channel):
        super(aggregation_final, self).__init__()
        self.relu = nn.ReLU(True)

        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.conv_upsample1 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample2 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample3 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample4 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv_upsample5 = BasicConv2d(2 * channel, 2 * channel, 3, padding=1)

        self.conv_concat2 = BasicConv2d(2 * channel, 2 * channel, 3, padding=1)
        self.conv_concat3 = BasicConv2d(3 * channel, 3 * channel, 3, padding=1)
        self.conv4 = BasicConv2d(3 * channel, 3 * channel, 3, padding=1)
        self.conv5 = nn.Conv2d(3 * channel, 1, 1)

    def forward(self, x1, x2, x3):
        x1_1 = x1
        x2_1 = self.conv_upsample1(self.upsample(x1)) * x2
        x3_1 = self.conv_upsample2(self.upsample(x1)) \
               * self.conv_upsample3(x2) * x3

        x2_2 = torch.cat((x2_1, self.conv_upsample4(self.upsample(x1_1))), 1)
        x2_2 = self.conv_concat2(x2_2)

        x3_2 = torch.cat((x3_1, self.conv_upsample5(x2_2)), 1)
        x3_2 = self.conv_concat3(x3_2)

        x1 = self.conv4(x3_2)
        x = self.conv5(x1)

        return x, x1


# Refinement flow
class Refine(nn.Module):
    def __init__(self):
        super(Refine, self).__init__()
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

    def forward(self, attention, x1, x2, x3):
        # Note that there is an error in the manuscript. In the paper, the refinement strategy is depicted as ""f'=f*S1"", it should be ""f'=f+f*S1"".
        x1 = x1 + torch.mul(x1, self.upsample2(attention))
        x2 = x2 + torch.mul(x2, self.upsample2(attention))
        x3 = x3 + torch.mul(x3, attention)

        return x1, x2, x3


# Refinement flow
class CACE(nn.Module):
    def __init__(self):
        super(CACE, self).__init__()
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.out_channel1_body = ChannelAttention(96)
        self.out_channel1_edge = ChannelAttention(96)

        self.out_spatial1_body = SpatialAttention()
        self.out_spatial1_edge = SpatialAttention()

        self.bt = nn.Conv2d(32 * 3, 32, kernel_size=1, stride=1, bias=True)
        self.et = nn.Conv2d(32 * 3, 32, kernel_size=1, stride=1, bias=True)

    def forward(self, body_r, body_d):
        body = body_r
        edge = body_d
        body_c = edge.mul(self.out_channel1_body(edge))
        edge_c = body.mul(self.out_channel1_edge(body))
        body_s_temp = edge_c.mul(self.out_spatial1_body(edge))
        edge_s_temp = body_c.mul(self.out_spatial1_edge(body))
        body_cs = body_s_temp
        edge_cs = edge_s_temp

        b = self.bt(body_cs)
        e = self.et(edge_cs)

        return b, e


class Fusion(nn.Module):
    def __init__(self):
        super(Fusion, self).__init__()
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.inplanes = 32
        self.deconv21 = self._make_transpose(TransBasicBlock, 32, 3, stride=2)
        self.deconv22 = self._make_transpose(TransBasicBlock, 32, 3, stride=2)
        self.deconv31 = self._make_transpose(TransBasicBlock, 32, 3, stride=2)
        self.deconv32 = self._make_transpose(TransBasicBlock, 32, 3, stride=2)
        self.deconv41 = self._make_transpose(TransBasicBlock, 32, 3, stride=2)
        self.deconv42 = self._make_transpose(TransBasicBlock, 32, 3, stride=2)

    def forward(self, b, e):
        ys0 = b + e  # 32 44 44

        b = self.deconv21(b)
        e = self.deconv22(e)
        ys1 = b + e + self.upsample2(ys0)  # 32 88 88

        b = self.deconv31(b)
        e = self.deconv32(e)
        ys2 = b + e + self.upsample2(ys1)  # 32 172 172

        b = self.deconv41(b)
        e = self.deconv42(e)
        ys3 = b + e + self.upsample2(ys2)  # 32 172 172

        return ys3

    def _make_transpose(self, block, planes, blocks, stride=1):
        upsample = None
        if stride != 1:
            upsample = nn.Sequential(
                nn.ConvTranspose2d(self.inplanes, planes,
                                   kernel_size=2, stride=stride,
                                   padding=0, bias=False),
                nn.BatchNorm2d(planes),
            )
        elif self.inplanes != planes:
            upsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes),
            )

        layers = []

        for i in range(1, blocks):
            layers.append(block(self.inplanes, self.inplanes))

        layers.append(block(self.inplanes, planes, stride, upsample))
        self.inplanes = planes

        return nn.Sequential(*layers)


# BBSNet
class BBSNet(nn.Module):
    def __init__(self, channel=32):
        super(BBSNet, self).__init__()

        # Backbone model
        self.resnet = ResNet50('rgb')
        self.resnet_depth = ResNet50('rgbd')

        # Decoder 1
        self.rfb2_1 = GCM(512, channel)
        self.rfb3_1 = GCM(1024, channel)
        self.rfb4_1 = GCM(2048, channel)
        self.agg1 = aggregation_init(channel)

        # Decoder 2
        self.rfb0_2 = GCM(64, channel)
        self.rfb1_2 = GCM(256, channel)
        self.rfb5_2 = GCM(512, channel)
        self.agg2 = aggregation_init(channel)

        # Decoder 1
        self.rfb2_1_d = GCM(512, channel)
        self.rfb3_1_d = GCM(1024, channel)
        self.rfb4_1_d = GCM(2048, channel)
        self.agg1_d = aggregation_init(channel)

        # Decoder 2
        self.rfb0_2_d = GCM(64, channel)
        self.rfb1_2_d = GCM(256, channel)
        self.rfb5_2_d = GCM(512, channel)
        self.agg2_d = aggregation_init(channel)

        # upsample function
        # self.upsample05 = nn.Upsample(scale_factor=0.5, mode='bilinear', align_corners=True)
        self.upsample4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.pool2 = nn.AvgPool2d(kernel_size=3, stride=2, padding=1)
        self.pool4 = nn.AvgPool2d(kernel_size=3, stride=4, padding=1)

        # Refinement flow
        self.CACE_r = CACE()
        self.CACE_d = CACE()

        self.fusion_r = Fusion()
        self.fusion_d = Fusion()
        self.fusion = Fusion()

        self.out0_conv = nn.Conv2d(32, 1, 1)
        self.out1_conv = nn.Conv2d(32, 1, 1)
        self.out2_conv = nn.Conv2d(32, 1, 1)

        # if self.training:
        #     self.initialize_weights()

    def forward(self, x, x_depth):
        x = self.resnet.conv1(x)
        x = self.resnet.bn1(x)
        x0 = self.resnet.relu(x)
        x = self.resnet.maxpool(x0)
        x1 = self.resnet.layer1(x)  # 256 x 64 x 64
        x2 = self.resnet.layer2(x1)  # 512 x 32 x 32
        x3_1 = self.resnet.layer3_1(x2)  # 1024 x 16 x 16
        x4_1 = self.resnet.layer4_1(x3_1)  # 2048 x 8 x 8

        x_depth = self.resnet_depth.conv1(x_depth)
        x_depth = self.resnet_depth.bn1(x_depth)
        x0_depth = self.resnet_depth.relu(x_depth)
        x_depth = self.resnet_depth.maxpool(x0_depth)
        x1_depth = self.resnet_depth.layer1(x_depth)
        x2_depth = self.resnet_depth.layer2(x1_depth)
        x3_1_depth = self.resnet_depth.layer3_1(x2_depth)
        x4_1_depth = self.resnet_depth.layer4_1(x3_1_depth)

        # decoder of rgb
        x0_2 = self.rfb0_2(x0)
        x1_2 = self.rfb1_2(x1)
        x2_2 = self.rfb2_1(x2)
        x3_2 = self.rfb3_1(x3_1)
        x4_2 = self.rfb4_1(x4_1)
        body_map_r, body_feature_r = self.agg1(x4_2, x3_2, x2_2)
        edge_map_r, edge_feature_r = self.agg2(x2_2, x1_2, x0_2)

        # decoder of depth
        x0_2_d = self.rfb0_2_d(x0_depth)
        x1_2_d = self.rfb1_2_d(x1_depth)
        x2_2_d = self.rfb2_1_d(x2_depth)
        x3_2_d = self.rfb3_1_d(x3_1_depth)
        x4_2_d = self.rfb4_1_d(x4_1_depth)
        body_map_d, body_feature_d = self.agg1_d(x4_2_d, x3_2_d, x2_2_d)
        edge_map_d, edge_feature_d = self.agg2_d(x2_2_d, x1_2_d, x0_2_d)

        # interaction
        body_feature_r, body_feature_d = self.CACE_r(body_feature_r, body_feature_d)
        edge_feature_r, edge_feature_d = self.CACE_d(self.pool4(edge_feature_r), self.pool4(edge_feature_d))

        # fusion
        fusion_rgb = self.fusion_r((body_feature_r), (edge_feature_d))
        fusion_depth = self.fusion_d((body_feature_d), (edge_feature_r))
        fusion_final = fusion_rgb + fusion_depth
        
        # output
        body_map_r = F.interpolate(body_map_r, scale_factor=8, mode='bilinear')
        edge_map_r = F.interpolate(edge_map_r, scale_factor=2, mode='bilinear')
        body_map_d = F.interpolate(body_map_d, scale_factor=8, mode='bilinear')
        edge_map_d = F.interpolate(edge_map_d, scale_factor=2, mode='bilinear')
        fusion_rgb = self.out0_conv(fusion_rgb)
        # fusion_rgb = F.interpolate(fusion_rgb, scale_factor=2, mode='bilinear')
        fusion_depth = self.out1_conv(fusion_depth)
        # fusion_depth = F.interpolate(fusion_depth, scale_factor=2, mode='bilinear')
        fusion_final = self.out2_conv(fusion_final)
        # fusion_final = F.interpolate(fusion_final, scale_factor=0.5, mode='bilinear')

        output_list = [body_map_r, edge_map_r, body_map_d, edge_map_d, fusion_rgb, fusion_depth, fusion_final]

        return output_list

    def _make_agant_layer(self, inplanes, planes):
        layers = nn.Sequential(
            nn.Conv2d(inplanes, planes, kernel_size=1,
                      stride=1, padding=0, bias=False),
            nn.BatchNorm2d(planes),
            nn.ReLU(inplace=True)
        )
        return layers

    def _make_transpose(self, block, planes, blocks, stride=1):
        upsample = None
        if stride != 1:
            upsample = nn.Sequential(
                nn.ConvTranspose2d(self.inplanes, planes,
                                   kernel_size=2, stride=stride,
                                   padding=0, bias=False),
                nn.BatchNorm2d(planes),
            )
        elif self.inplanes != planes:
            upsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes),
            )

        layers = []

        for i in range(1, blocks):
            layers.append(block(self.inplanes, self.inplanes))

        layers.append(block(self.inplanes, planes, stride, upsample))
        self.inplanes = planes

        return nn.Sequential(*layers)

    # initialize the weights
    def initialize_weights(self):
        res50 = models.resnet50(pretrained=True)
        pretrained_dict = res50.state_dict()
        all_params = {}
        for k, v in self.resnet.state_dict().items():
            if k in pretrained_dict.keys():
                v = pretrained_dict[k]
                all_params[k] = v
            elif '_1' in k:
                name = k.split('_1')[0] + k.split('_1')[1]
                v = pretrained_dict[name]
                all_params[k] = v
            elif '_2' in k:
                name = k.split('_2')[0] + k.split('_2')[1]
                v = pretrained_dict[name]
                all_params[k] = v
        assert len(all_params.keys()) == len(self.resnet.state_dict().keys())
        self.resnet.load_state_dict(all_params)

        all_params = {}
        for k, v in self.resnet_depth.state_dict().items():
            if k == 'conv1.weight':
                all_params[k] = torch.nn.init.normal_(v, mean=0, std=1)
            elif k in pretrained_dict.keys():
                v = pretrained_dict[k]
                all_params[k] = v
            elif '_1' in k:
                name = k.split('_1')[0] + k.split('_1')[1]
                v = pretrained_dict[name]
                all_params[k] = v
            elif '_2' in k:
                name = k.split('_2')[0] + k.split('_2')[1]
                v = pretrained_dict[name]
                all_params[k] = v
        assert len(all_params.keys()) == len(self.resnet_depth.state_dict().keys())
        self.resnet_depth.load_state_dict(all_params)

if __name__ == '__main__':
    imput = torch.rand(1,3,352,352)
    model = BBSNet()
    output = model(imput, imput)
    print(output)

