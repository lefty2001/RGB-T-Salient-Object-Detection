def draw_spongebob():
    """
    Draws a Spongebob character using the turtle library.
    """
    import turtle
    t = turtle.Turtle()

    # Draw the head
    t.penup()
    t.setpos(-50, 0)
    t.pendown()
    t.circle(50)

    # Draw the eyes
    t.penup()
    t.setpos(-30, 30)
    t.pendown()
    t.circle(10)

    t.penup()
    t.setpos(-70, 30)
    t.pendown()
    t.circle(10)

    # Draw the mouth
    t.penup()
    t.setpos(-50, -20)
    t.pendown()
    t.circle(30, 180)

    # Draw the arms
    t.penup()
    t.setpos(-80, -50)
    t.pendown()
    t.right(45)
    t.forward(50)

    t.penup()
    t.setpos(20, -50)
    t.pendown()
    t.left(90)
    t.forward(50)

    # Draw the legs
    t.penup()
    t.setpos(-30, -100)
    t.pendown()
    t.right(45)
    t.forward(50)

    t.penup()
    t.setpos(40, -100)
    t.pendown()
    t.left(90)
    t.forward(50)

    # Hide the turtle
    t.hideturtle()